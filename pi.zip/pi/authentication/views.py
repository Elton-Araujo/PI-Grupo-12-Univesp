from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout

# Create your views here.
def home(request):
    return render(request, "authentication/index.html")

def signup(request):
    if request.method == "POST":
        nome = request.POST['nome']
        snome = request.POST['snome']
        user = request.POST['user']
        email = request.POST['email']
        senha = request.POST['senha']
        csenha = request.POST['csenha']

        
        if User.objects.filter(username = user).first():
            messages.error(request, "This username is already taken")
            return redirect('home')
        else:
            myuser = User.objects.create_user(user, email, senha)
            myuser.first_name = nome
            myuser.last_name = snome
            
            myuser.save()

        messages.success(request, "Conta criada com sucesso!")

        return redirect('home')
    return render(request, "authentication/signup.html")

def signin(request):
    if request.method == 'POST':
        username = request.POST['user']
        senha = request.POST['senha']

        user = authenticate(username=username, password=senha)

        if user is not None:
            login(request, user)
            nome = user.first_name
            return render(request, "authentication/index.html", {'nome': nome})
        else:
            messages.error(request, "Usuário ou senha errados")
            return redirect('home')
        
    return render(request, "authentication/signin.html")

def signout(request):
    logout(request)
    messages.success(request, "Deslogado")
    return redirect('home')